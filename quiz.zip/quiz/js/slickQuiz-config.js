// Setup your quiz text and questions here

// NOTE: pay attention to commas, IE struggles with those bad boys

var quizJSON = {
    "info": {
        "main":    "",
        "results": "<h5>Learn More</h5><p>Etiam scelerisque, nunc ac egestas consequat, odio nibh euismod nulla, eget auctor orci nibh vel nisi. Aliquam erat volutpat. Mauris vel neque sit amet nunc gravida congue sed sit amet purus.</p>",
        levels:{
        "level1":  {"title": "Pineapple", "descShort":"PINEAPPLE", "descLong":"", image: "pizza.png", image1:"checkmark.png",rangeStart: 0, rangeEnd: 7 },
        "level2":  {"title": "Banana", "descShort":"BANANA", "descLong":"", image: "pizza.png", image1:"checkmark.png", rangeStart: 8, rangeEnd: 14},
        "level3":  {"title": "Apple", "descShort":"APPLE", "descLong":"", image: "pizza.png", image1:"checkmark.png", rangeStart: 15, rangeEnd: 21},
        "level4":  {"title": "Strawberry", "descShort":"STRAWBERRY",  "descLong":"", image: "pizza.png", image1:"checkmark.png", rangeStart: 22, rangeEnd: 28},
        "level5":  {"title": "Cherry", "descShort":"CHERRY",  "descLong":"", image: "pizza.png", image1:"checkmark.png", rangeStart: 29, rangeEnd: 35},
        "level6":  {"title": "Oranges", "descShort":"ORANGES",  "descLong":"", image: "pizza.png", image1:"checkmark.png", rangeStart: 36, rangeEnd: 42} // no comma here// no comma here
        }

        // levels:{
        // "level1":  {"title": "Pineapple", "descShort":"PINEAPPLE", "descLong":"", "image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 0, "rangeEnd": 7 },
        // "level2":  {"title": "Banana", "descShort":"BANANA", "descLong":"", "image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 8, "rangeEnd": 14},
        // "level3":  {"title": "Apple", "descShort":"APPLE", "descLong":"", "image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 15, "rangeEnd": 21},
        // "level4":  {"title": "Strawberry", "descShort":"STRAWBERRY",  "descLong":"","image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 22, "rangeEnd": 28},
        // "level5":  {"title": "Cherry", "descShort":"CHERRY",  "descLong":"", "image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 29, "rangeEnd": 35},
        // "level6":  {"title": "Oranges", "descShort":"ORANGES",  "descLong":"", "image":[ "pizza.png","pizza.png","pizza.png"], "rangeStart": 36, "rangeEnd": 42} // no comma here// no comma here
        // }
    },
    "questions": [
        { // Question 1 - Multiple Choice, Single True Answer
            "q": "PICK AN AVTAAR",
            "a": [
                {"option": "option1","correct": true, "value":"2", "image": "boyy.png"},
                {"option": "option2","correct": true, "value":"5", "image": "girl.png"}// no comma here
            ],
        },
        { // Question 2 - Multiple Choice, Multiple True Answers, Select Any
            "q": "How do you feel about dancing? ",
            "a": [
                {"option": "Heels", "correct": true, "value":"4", "image": "quiz-thumbimg-dance1.jpg"},
                {"option": "Work boots", "correct": true, "value":"0", "image": "quiz-thumbimg-dance2.jpg"} // no comma here
            ],
        },
        { // Question 3 - Multiple Choice, Multiple True Answers, Select All
            "q": "WHAT WOULD YOU BRING TO A DESERT ISLAND?",
            "a": [
                {"option": "Cheetos","correct": true, "value":"1", "image": "quiz-thumbimg-island1.jpg"},
                {"option": "Sun screen","correct": true, "value":"2", "image": "quiz-thumbimg-island2.jpg"}
               // no comma here
            ],

        },
        { // Question 4
            "q": "WHICH ANIMAL'S LOOK ARE YOU FEELING?",
            "a": [
                {"option": "Luxury apartment","correct": true, "value":"4", "image": "quiz-thumbimg-animal1.jpg"},
                {"option": "Beach house","correct": true, "value":"3", "image": "quiz-thumbimg-animal2.jpg"}// no comma here
            ],
        },
        { // Question 5
            "q": "PICK A VEGETABLE",
            "a": [
                {"option": "Veg 1","correct": true, "value":"4", "image": "quiz-thumbimg-veg1.jpg"},
				{"option": "Veg 2","correct": true, "value":"5", "image": "quiz-thumbimg-veg2.jpg"} // no comma here
            ],

        },
		{ // Question 6
            "q": "PICK A PLANET",
            "a": [
                {"option": "New Year’s Eve","correct": true, "value":"0", "image": "quiz-thumbimg-planet1.jpg"},
				{"option": "Fourth of July","correct": true, "value":"4", "image": "quiz-thumbimg-planet2.jpg"} // no comma here
            ],

        }, 
		{ // Question 7
            "q": "WHAT ARE YOU MOST LIKELY DOING AT A PARTY?",
            "a": [
                {"option": "New York City","correct": true, "value":"5", "image": "quiz-thumbimg-party1.jpg"},
				{"option": "Seattle","correct": true, "value":"0", "image": "quiz-thumbimg-party2.jpg"} // no comma here
            ],

        } // no comma here// no comma here
		
    ]
};
